0
sudo apt-get  install php5-mysql
1
sudo apt-get install sendmail
2


